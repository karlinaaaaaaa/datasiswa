<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {

	public function index()

    {
        echo"halaman daftar";
    }
    
    public function login()
    {
        echo"ini login";
    }

	public function home()
    {
		echo"ini home";
	}


}