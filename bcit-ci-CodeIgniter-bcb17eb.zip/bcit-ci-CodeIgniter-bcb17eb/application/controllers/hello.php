<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {

	public function index()
	{
		echo $data;
	}
}
public function tampil(){
    $data['judul'] ="halaman_tampil";
    $data['deskripsi'] ="ini deskripsi";
    //                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
}