<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class coba extends CI_Controller {
        public function index()
        {

            $query = $this->db->get('')->result();

            foreach ($query as $query){
                echo "<p> $query-></p>";
            }
        }
}